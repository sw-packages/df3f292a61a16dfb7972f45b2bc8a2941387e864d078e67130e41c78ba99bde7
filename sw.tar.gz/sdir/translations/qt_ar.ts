<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar">
<dependencies>
<dependency catalog="qtbase_ar"/>
<dependency catalog="qtscript_ar"/>
<dependency catalog="qtmultimedia_ar"/>
</dependencies>
</TS>
