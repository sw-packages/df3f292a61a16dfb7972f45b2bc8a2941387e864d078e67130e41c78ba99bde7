<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
    <dependencies>
        <dependency catalog="qtbase_fr"/>
        <dependency catalog="qtscript_fr"/>
        <dependency catalog="qtmultimedia_fr"/>
        <dependency catalog="qtxmlpatterns_fr"/>
    </dependencies>
</TS>
