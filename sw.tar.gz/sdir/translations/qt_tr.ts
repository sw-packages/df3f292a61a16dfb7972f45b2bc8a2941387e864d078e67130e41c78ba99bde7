<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<dependencies>
<dependency catalog="qtbase_tr"/>
<dependency catalog="qtscript_tr"/>
<dependency catalog="qtmultimedia_tr"/>
</dependencies>
</TS>
